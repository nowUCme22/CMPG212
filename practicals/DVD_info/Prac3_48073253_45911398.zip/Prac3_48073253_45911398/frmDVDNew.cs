﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Prac3_48073253_45911398
{
    public partial class frmDVDNew : Form
    {
        //variables
        SqlConnection conn;
        SqlCommand comm;

        //estab;ish connection
        string conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True";

        public frmDVDNew()
        {
            InitializeComponent();
        }

        private void frmDVDNew_Load(object sender, EventArgs e)
        {
            //text get age from scrollbar
            lblAge.Text = hsbAge.Value.ToString();
        }

        public void PopulateDataGridView(DataTable data)
        {
            dgvDVD.DataSource = data;
        }

        private void btnAction_Click(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(conString);
                conn.Open();

                //populate
                SqlDataAdapter adapt = new SqlDataAdapter();
                string sql = "SELECT * FROM tblDVD WHERE Type LIKE  '%ACT%'";
                comm = new SqlCommand(sql, conn);

                DataSet ds = new DataSet();

                adapt.SelectCommand = comm;
                adapt.Fill(ds,"DVD");


                //pass to child form
                dgvDVD.DataSource = ds;
                dgvDVD.DataMember = "DVD";
                //child1.PopulateDataGridView(dt);


            }
            catch (Exception ex)
            {
                //error message
                MessageBox.Show("Error !!!!! Could not load data: " + ex.Message);
            }
            finally
            {
                //close database
                conn.Close();
            }
        }

        private void hsbAge_Scroll(object sender, ScrollEventArgs e)
        {
            lblAge.Text = hsbAge.Value.ToString();

            try
            {
                conn = new SqlConnection(conString);
                conn.Open();

                //populate
                SqlDataAdapter adapt = new SqlDataAdapter();
                string sql = "SELECT * FROM tblDVD WHERE Age <=  "+ hsbAge.Value.ToString() ;
                comm = new SqlCommand(sql, conn);

                DataSet ds = new DataSet();

                adapt.SelectCommand = comm;
                adapt.Fill(ds, "DVD");


                //pass to child form
                dgvDVD.DataSource = ds;
                dgvDVD.DataMember = "DVD";
                //child1.PopulateDataGridView(dt);


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error !!!!! Could not load data: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }


        }
    }
}
