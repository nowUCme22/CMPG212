﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Prac3_48073253_45911398
{
   
    public partial class Form1 : Form
    { 
        SqlConnection conn;
        SqlCommand comm;

        //establish connection
        string conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True";
        

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(conString);
                conn.Open();

            }
            catch
            {
                MessageBox.Show("Error !!!!! Connection not established");
            }
            finally 
            { 
                conn.Close(); 
            }
           

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //exit program
            Application.Exit();
        }

        private void listDVDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //open child form
            frmDVDNew child1 = new frmDVDNew();
            child1.MdiParent = this;
            child1.Show();


            try
            {
                conn = new SqlConnection(conString);
                conn.Open();

                //populate
                SqlDataAdapter adapt = new SqlDataAdapter();
                string sql = "SELECT * FROM tblDVD";
                comm = new SqlCommand(sql, conn);

                DataTable dt = new DataTable();

                adapt.SelectCommand = comm;
                adapt.Fill(dt);


                //pass to child form
                child1.PopulateDataGridView(dt);


            }
            catch(Exception ex)
            {
                MessageBox.Show("Error !!!!! Could not load data: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }

           
        }
    }
}
