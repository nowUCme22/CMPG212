﻿
namespace Prac3_48073253_45911398
{
    partial class frmDVDNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvDVD = new System.Windows.Forms.DataGridView();
            this.btnAction = new System.Windows.Forms.Button();
            this.hsbAge = new System.Windows.Forms.HScrollBar();
            this.lblAge = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDVD)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvDVD
            // 
            this.dgvDVD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDVD.Location = new System.Drawing.Point(0, 0);
            this.dgvDVD.Name = "dgvDVD";
            this.dgvDVD.RowHeadersWidth = 51;
            this.dgvDVD.RowTemplate.Height = 24;
            this.dgvDVD.Size = new System.Drawing.Size(798, 255);
            this.dgvDVD.TabIndex = 0;
            // 
            // btnAction
            // 
            this.btnAction.Location = new System.Drawing.Point(34, 272);
            this.btnAction.Name = "btnAction";
            this.btnAction.Size = new System.Drawing.Size(191, 83);
            this.btnAction.TabIndex = 1;
            this.btnAction.Text = "Action movies";
            this.btnAction.UseVisualStyleBackColor = true;
            this.btnAction.Click += new System.EventHandler(this.btnAction_Click);
            // 
            // hsbAge
            // 
            this.hsbAge.Location = new System.Drawing.Point(270, 326);
            this.hsbAge.Name = "hsbAge";
            this.hsbAge.Size = new System.Drawing.Size(504, 29);
            this.hsbAge.TabIndex = 2;
            this.hsbAge.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hsbAge_Scroll);
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAge.Location = new System.Drawing.Point(475, 284);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(54, 29);
            this.lblAge.TabIndex = 3;
            this.lblAge.Text = "age";
            // 
            // frmDVDNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.hsbAge);
            this.Controls.Add(this.btnAction);
            this.Controls.Add(this.dgvDVD);
            this.Name = "frmDVDNew";
            this.Text = "New DVD";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmDVDNew_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDVD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDVD;
        private System.Windows.Forms.Button btnAction;
        private System.Windows.Forms.HScrollBar hsbAge;
        private System.Windows.Forms.Label lblAge;
    }
}