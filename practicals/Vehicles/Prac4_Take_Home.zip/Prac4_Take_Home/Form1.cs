﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Prac4_Take_Home
{
    public partial class Form1 : Form
    {
        SqlConnection conn;
        SqlCommand comm;
        //connect database
        String conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\dbVehicles.mdf;Integrated Security=True";
        SqlDataAdapter adapt;
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        //method
        public void LoadData()
        {
            try
            {
                conn = new SqlConnection(conString);
                conn.Open();

                string sql = "SELECT * FROM tblVehicles";
                comm = new SqlCommand(sql, conn);

                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter(comm);
                adapt.Fill(dt);

                dgvVehicles.DataSource = dt;
            }
            catch
            {
                MessageBox.Show("Error loading data.");
            }
            finally
            {
                conn.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            LoadData();
            //connect database
           /* try
            {
                conn = new SqlConnection(conString);
                conn.Open();

                //populate datagrid
                SqlDataAdapter adapt = new SqlDataAdapter();
                string sql = "SELECT * FROM tblVehicles";
                comm = new SqlCommand(sql, conn);

                DataTable dt = new DataTable();

                adapt.SelectCommand = comm;
                adapt.Fill(dt);

                dgvVehicles.DataSource = dt;




                
            }
            catch
            {
                MessageBox.Show("Error connecting database");
            }
            finally 
            {
                conn.Close();
            }*/
            
            
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string query = "SELECT * FROM tblVehicles WHERE VIN_Number LIKE '%" + txtSearch.Text + 
                "%' OR  Brand LIKE '%" + txtSearch.Text + 
                "%' OR  Model LIKE '%" + txtSearch.Text + 
                "%' OR  Year LIKE '%" + txtSearch.Text + 
                "%' OR  Type LIKE '%" + txtSearch.Text + "%'";
            try
            {
                conn = new SqlConnection(conString);
                conn.Open();

                comm = new SqlCommand(query, conn);

                DataSet ds = new DataSet();
                adapt = new SqlDataAdapter();

                adapt.SelectCommand = comm;
                adapt.Fill(ds,"Vehicles");

                dgvVehicles.DataSource = ds;
                dgvVehicles.DataMember = "Vehicles";

            }
            catch
            {
                MessageBox.Show("Error connecting to Data");
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            frDelete child = new frDelete();
            child.MdiParent = this;
            child.Show();

            frDelete deleteForm = new frDelete();
            deleteForm.ShowDialog();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(conString))
                {
                    conn.Open(); // Open connection

                    string insertQuery = "INSERT INTO tblVehicles (VIN_Number, Brand, Model, Year, Type) VALUES (@Number, @Brand, @Model, @Year, @Type)";

                    using (SqlCommand comm = new SqlCommand(insertQuery, conn))
                    {
                        // Add parameters with values
                        comm.Parameters.AddWithValue("@Number", txtNumber.Text.Trim());
                        comm.Parameters.AddWithValue("@Brand", txtBrand.Text.Trim());
                        comm.Parameters.AddWithValue("@Model", txtModel.Text.Trim());
                        comm.Parameters.AddWithValue("@Year", txtYear.Text.Trim());
                        comm.Parameters.AddWithValue("@Type", cbxType.SelectedItem?.ToString() ?? string.Empty);

                        int rowsAffected = comm.ExecuteNonQuery(); // Execute once

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Successfully added");
                            LoadData(); // Refresh the data grid or list

                            // Clear input fields
                            txtNumber.Clear();
                            txtBrand.Clear();
                            txtModel.Clear();
                            txtYear.Clear();
                            cbxType.SelectedIndex = -1;
                        }
                        else
                        {
                            MessageBox.Show("Insertion failed");
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"Database error: {sqlEx.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }
    }
}
