﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Prac4_Take_Home
{
    public partial class frDelete : Form
    {
        SqlConnection conn;
        SqlCommand comm;
        //connect database
        String conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\dbVehicles.mdf;Integrated Security=True";
        SqlDataAdapter adapt;

        public frDelete()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string delete = txtDelete.Text;
            string query = "DELETE FROM tblVehicles WHERE Model = @delete";
            try
            {
                conn = new SqlConnection(conString);
                conn.Open();

                comm = new SqlCommand(query, conn);
                comm.Parameters.AddWithValue("@delete", delete);

                if (comm.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Record deleted successfully!");

                    Form1 mainForm = (Form1)Application.OpenForms["Form1"];
                    mainForm.LoadData();

                    this.Close();
                }
                else
                {
                    MessageBox.Show("No record found");
                }



            }
            catch
            {
                MessageBox.Show("Error connecting to Data");
            }
            finally
            {
                conn.Close();
            }
        }

        private void frDelete_Load(object sender, EventArgs e)
        {
            
        }
    }
}
